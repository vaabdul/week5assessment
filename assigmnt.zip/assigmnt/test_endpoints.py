import pytest
from app import app, db

@pytest.fixture
def client():
    app.config['TESTING'] = True
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
    with app.test_client() as client:
        with app.app_context():
            db.create_all()
        yield client
        with app.app_context():
            db.drop_all()

def test_create_furniture(client):
    # Test creating a new furniture item
    response = client.post('/furniture', data={
        'name': 'Chair',
        'description': 'Comfortable chair',
        'quantity': 10,
        'location': 'Living room'
    })
    assert response.status_code == 201

    # Test retrieving the created furniture item
    response = client.get('/furniture')
    data = response.json
    assert len(data['furniture']) == 1
    assert data['furniture'][0]['name'] == 'Chair'

# Similarly, define test functions for update and delete operations
