import unittest
from app import app, db
import json

class TestFurnitureCRUD(unittest.TestCase):
    def setUp(self):
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        self.app = app.test_client()

        # Establish application context
        with app.app_context():
            db.create_all()

    def tearDown(self):
        # Drop all tables and remove the session
        with app.app_context():
            db.session.remove()
            db.drop_all()

    def test_create_furniture(self):
    # Test creating a new furniture item
        #  Test creating a new furniture item
        response = self.app.post('/furniture', data={
            'name': 'Chair',
            'description': 'Comfortable chair',
            'quantity': 10,
            'location': 'Living room'
        })
        self.assertEqual(response.status_code, 201)
        self.assertIn('message', response.json)


# Similar modifications can be made to other test methods


    def test_update_furniture(self):
        # Create a new furniture item
        # Update an existing furniture item
    response = self.app.put('/furniture/1/update', data={
        'name': 'New Chair Name',
        'description': 'New chair description',
        'quantity': 5,
        'location': 'New location'
    })
    self.assertEqual(response.status_code, 200)

    def test_delete_furniture(self):
        # Delete an existing furniture item
        response = self.app.delete('/furniture/1/delete')

        # Check if response data is empty
        if response.data:
            try:
                data = response.json
                # Add assertions for successful deletion here
            except json.decoder.JSONDecodeError:
                self.fail("Response data is not valid JSON")
        else:
            self.fail("No response data received")

if __name__ == '__main__':
    unittest.main()
